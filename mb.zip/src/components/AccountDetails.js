import React, {Component} from 'react';
import {View} from 'react-native';
import {
  Select,
  Card,
  Text,
  Input,
  SelectItem,
  Button,
} from '@ui-kitten/components';
import Icon from 'react-native-vector-icons/FontAwesome';
import style from '../assets/style';
import banks from '../config/banks.json';

export default class AccountDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedIndex: 0,
      checked: false,
      data: banks.map((b) => b.name),
      bankName: '',
      accountNumber: '',
      walletAdress: '',
    };
  }

  renderOption = (title) => <SelectItem key={`${title}`} title={title} />;

  render() {
    const {checked, selectedIndex} = this.state;
    return (
      <Card style={[style.fullHeight, style.noBorder, style.progressComponent]}>
        <View style={{marginTop: 10}}>
          <Text category="p1" style={[style.openSansRegular, style.colorLight]}>
            Bank Name
          </Text>
          <Select
            selectedIndex={selectedIndex}
            style={[style.input, style.boxWithShadow]}
            value={this.state.data[selectedIndex.row]}
            defaultValue={this.state.bankName ? this.state.bankName : ''}
            onSelect={(index) =>
              this.setState({
                selectedIndex: index,
                bankName: this.state.data[selectedIndex.row],
              })
            }>
            {this.state.data.map(this.renderOption)}
          </Select>
        </View>

        <View>
          <Input
            textStyle={{height: 30}}
            label={(evaProps) => (
              <Text
                category="p1"
                {...evaProps}
                style={[style.openSansRegular, style.label, style.colorLight]}>
                Account Number
              </Text>
            )}
            style={[style.input, style.boxWithShadow]}
            defaultValue={this.state.accountNumber}
            placeholder=""
            keyboardType="numeric"
          />
        </View>
        <View>
          <Input
            textStyle={{height: 30}}
            label={(evaProps) => (
              <Text
                category="p1"
                {...evaProps}
                style={[style.openSansRegular, style.label, style.colorLight]}>
                BTC/USDT Wallet Address{' '}
              </Text>
            )}
            style={[style.input, style.boxWithShadow]}
            defaultValue={this.state.walletAdress}
            placeholder="Optional"
            keyboardType="visible-password"
          />
        </View>
        <Button
          style={[
            style.sm_margin,
            style.primaryBackground,
            style.openSansRegular,
            style.noBorder,
          ]}>
          Submit
        </Button>
      </Card>
    );
  }
}
