import React, {Component} from 'react';
import * as firebase from 'firebase';

import {
  TouchableOpacity,
  View,
  LogBox,
  StyleSheet,
  ActivityIndicator,
  Image,
} from 'react-native';
import {
  Select,
  Card,
  Text,
  SelectItem,
  Input,
  Radio,
  Button,
} from '@ui-kitten/components';
import * as ImagePicker from 'expo-image-picker';
import * as Clipboard from 'expo-clipboard';
import {v4} from 'uuid';

import style from '../assets/style';
import openImagePickerAsync from './ImageUploader';
import {Icon, Thumbnail} from 'native-base';
import Modal from './modal';
import * as Animatable from 'react-native-animatable';
import styles from '../assets/style';

const firebaseConfig = {
  apiKey: 'AIzaSyAb_74Slm90KkDIdhGZR3bVrwGm30T3W0c',
  authDomain: 'vglobal-dbx.firebaseapp.com',
  projectId: 'vglobal-dbx',
  storageBucket: 'vglobal-dbx.appspot.com',
  messagingSenderId: '397365610818',
  appId: '1:397365610818:web:cf51910e241fa6877860db',
  measurementId: 'G-VEEZYR902B',
};

if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}
LogBox.ignoreLogs([`Setting a timer for a long period`]);

export default class KYCInfo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedIndex: 0,
      checked: false,
      data: ['Nation ID', 'Driver License', 'International Passport'],
      ID: '',
      idNumber: '',
      imageUriFront: '',
      imageUriBack: '',
      image: null,
      uploading: false,
      modalVisible: true,
      radio1: false,
      radio2: false,
    };
  }

  renderOption = (title) => <SelectItem key={`${title}`} title={title} />;

  async componentDidMount() {
    if (Platform.OS !== 'web') {
      const {status} = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        alert('Sorry, we need camera roll permissions to make this work!');
      }
    }
  }

  render() {
    let {image, selectedIndex} = this.state;

    return (
      <Card style={[style.fullHeight, style.noBorder, style.progressComponent]}>
        <View style={{flex: 1}}>
          <View style={{marginTop: 10}}>
            <Text
              category="p1"
              style={[style.openSansRegular, style.colorLight]}>
              Means Of Identification
            </Text>
            <Select
              selectedIndex={selectedIndex}
              style={[style.input, style.boxWithShadow]}
              value={this.state.data[selectedIndex.row]}
              onSelect={(index) => this.setState({selectedIndex: index})}>
              {this.state.data.map(this.renderOption)}
            </Select>
          </View>
          <View>
            <Input
              textStyle={{height: 30}}
              label={(evaProps) => (
                <Text
                  category="p1"
                  {...evaProps}
                  style={[
                    style.openSansRegular,
                    style.label,
                    style.colorLight,
                  ]}>
                  Upload ID Card/Passport Number
                </Text>
              )}
              style={[style.input, style.boxWithShadow]}
              defaultValue=""
              placeholder="ID Number"
              keyboardType="visible-password"
            />
          </View>
          <View style={{height: 200}}>
            <TouchableOpacity
              style={{
                marginVertical: 30,
                fontFamily: 'ProductSans-Regular',
                backgroundColor: '#EEF5FD',
                height: 40,
                shadowColor: '#eee',
                shadowOffset: {width: 0, height: 1},
                shadowOpacity: 0.5,
                shadowRadius: 2,
                elevation: 3,
                alignItems: 'center',
                justifyContent: 'center',
              }}
              onPress={() => {
                this._pickImage('front');
              }}>
              <Text
                style={[
                  {top: -25, left: 0, color: '#3B5472', position: 'absolute'},
                  style.openSansRegular,
                ]}>
                Upload ID Image (Front)
              </Text>
              <Text>
                <Icon name="arrow-up" />
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                marginVertical: 10,
                fontFamily: 'ProductSans-Regular',
                backgroundColor: '#EEF5FD',
                height: 40,
                shadowColor: '#eee',
                shadowOffset: {width: 0, height: 1},
                shadowOpacity: 0.5,
                shadowRadius: 2,
                elevation: 3,
                alignItems: 'center',
                justifyContent: 'center',
              }}
              onPress={() => {
                this._pickImage('back');
              }}>
              <Text
                style={[
                  {top: -25, left: 0, color: '#3B5472', position: 'absolute'},
                  style.openSansRegular,
                ]}>
                Upload ID Image (back)
              </Text>
              <Text>
                <Icon name="arrow-up" style={{}} />
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        {this.state.imageUriFront || this.state.imageUriBack ? (
          <View
            style={{
              width: '100%',
              height: 80,
              flex: 1,
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginTop: -20,
              marginVertical: 20,
            }}>
            {this.state.imageUriFront ? (
              <View
                style={{
                  justifyContent: 'center',
                  alignItems: 'center',
                  width: '50%',
                }}>
                <Text>Front</Text>
                <Image
                  style={{width: '95%', height: '100%'}}
                  source={{
                    uri: `${this.state.imageUriFront}`,
                  }}
                />
              </View>
            ) : (
              <Text />
            )}
            {this.state.imageUriBack ? (
              <View
                style={{
                  justifyContent: 'center',
                  alignItems: 'center',
                  width: '50%',
                }}>
                <Text>Back</Text>
                <Image
                  style={{width: '95%', height: '100%'}}
                  source={{
                    uri: `${this.state.imageUriBack}`,
                  }}
                />
              </View>
            ) : (
              <Text />
            )}
          </View>
        ) : (
          <View />
        )}

        <Button
          style={[
            style.sm_margin,
            style.primaryBackground,
            style.openSansRegular,
            style.noBorder,
          ]}>
          Submit
        </Button>
      </Card>
    );
  }

  _pickImage = async (type) => {
    let pickerResult = await ImagePicker.launchImageLibraryAsync({});
    if (pickerResult.cancelled) return;
    this.handleSetImg(type, pickerResult.uri);
    // this._handleImagePicked(pickerResult);
  };
  handleSetImg(type, uri) {
    console.log({type, uri});
    if (type === 'front') {
      this.setState({imageUriFront: uri});
      return;
    }
    this.setState({imageUriBack: uri});
  }
  _handleImagePicked = async (uri) => {
    try {
      this.setState({uploading: true});

      const uploadUrl = await uploadImageAsync(uri);
      this.setState({image: uploadUrl});
    } catch (e) {
      console.log({ERROR: e.message});
      alert('Upload failed, sorry ');
    } finally {
      this.setState({uploading: false});
    }
  };
}

async function uploadImageAsync(uri) {
  // Why are we using XMLHttpRequest? See:
  // https://github.com/expo/expo/issues/2402#issuecomment-443726662
  const blob = await new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.onload = function () {
      resolve(xhr.response);
    };
    xhr.onerror = function (e) {
      console.log(e);
      reject(new TypeError('Network request failed'));
    };
    xhr.responseType = 'blob';
    xhr.open('GET', uri, true);
    xhr.send(null);
  });

  const ref = firebase.storage().ref().child(`identity/${Date.now()}`);

  const snapshot = await ref.put(blob);

  // We're done with the blob, close and release it
  blob.close();

  const res = await snapshot.ref.getDownloadURL();
  console.log(res);
  return res;
}
