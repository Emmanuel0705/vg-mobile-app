import React, {Component} from 'react';
import {View} from 'react-native';
import {
  Card,
  Text,
  SelectItem,
  Select,
  Input,
  Button,
} from '@ui-kitten/components';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import style from '../assets/style';
import {ScrollView} from 'react-native-gesture-handler';
import countries from '../config/countries.json';

export default class SenderInfo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      firstName: '',
      lastName: '',
      middleName: '',
      email: '',
      gender: '',
      phoneNumber: '',
      whatsApp: '',
      city: '',
      address: '',
      selectedIndex: 0,
      genders: ['Male', 'female'],
      countries,
      country: '',
      state: '',
      countryIndex: 0,
    };
  }
  calendarIcon() {
    return <Icon name="calendar" size={20} color="#000" />;
  }

  renderOption = (title, i) => <SelectItem key={`i${title}`} title={title} />;

  render() {
    const {selectedIndex} = this.state;

    return (
      <Card style={[style.fullHeight, style.noBorder, style.progressComponent]}>
        <View>
          <Input
            textStyle={{height: 30}}
            label={(evaProps) => (
              <Text
                category="p1"
                {...evaProps}
                style={[style.openSansRegular, style.label, style.colorLight]}>
                First Name
              </Text>
            )}
            style={[style.input, style.boxWithShadow]}
            defaultValue={this.state.firstName}
            placeholder="First Name"
            onChangeText={(e) => this.setState({firstName: e})}
          />
        </View>
        <View>
          <Input
            textStyle={{height: 30}}
            label={(evaProps) => (
              <Text
                category="p1"
                {...evaProps}
                style={[style.openSansRegular, style.label, style.colorLight]}>
                Last Name
              </Text>
            )}
            style={[style.input, style.boxWithShadow]}
            defaultValue={this.state.LastName}
            placeholder="Surname"
            onChangeText={(e) => this.setState({LastName: e})}
          />
        </View>
        <View>
          <Input
            textStyle={{height: 30}}
            label={(evaProps) => (
              <Text
                category="p1"
                {...evaProps}
                style={[style.openSansRegular, style.label, style.colorLight]}>
                Middle Name
              </Text>
            )}
            style={[style.input, style.boxWithShadow]}
            defaultValue={this.state.middleName}
            placeholder="Middle Name"
            onChangeText={(e) => this.setState({MiddleName: e})}
          />
        </View>
        <View>
          <Input
            textStyle={{height: 30}}
            label={(evaProps) => (
              <Text
                category="p1"
                {...evaProps}
                style={[style.openSansRegular, style.label, style.colorLight]}>
                Email
              </Text>
            )}
            style={[style.input, style.boxWithShadow]}
            defaultValue={this.state.email}
            placeholder="123@example.com"
            keyboardType="email-address"
            onChangeText={(e) => this.setState({email: e})}
          />
        </View>
        <View style={{marginTop: 10}}>
          <Text
            category="p1"
            style={[style.openSansRegular, style.label2, style.colorLight]}>
            Gender
          </Text>
          <Select
            selectedIndex={selectedIndex}
            style={[style.input, style.boxWithShadow]}
            defaultValue={this.state.gender}
            value={this.state.genders[selectedIndex.row]}
            onSelect={(index) => this.setState({selectedIndex: index})}>
            {this.state.genders.map(this.renderOption)}
          </Select>
        </View>
        <View>
          <Input
            textStyle={{height: 30}}
            label={(evaProps) => (
              <Text
                category="p1"
                {...evaProps}
                style={[style.openSansRegular, style.label, style.colorLight]}>
                Phone Number
              </Text>
            )}
            style={[style.input, style.boxWithShadow]}
            defaultValue={this.state.phoneNumber}
            placeholder="+1234567890"
            keyboardType="phone-pad"
            onChangeText={(e) => this.setState({phoneNumber: e})}
          />
        </View>
        <View>
          <Input
            textStyle={{height: 30}}
            label={(evaProps) => (
              <Text
                category="p1"
                {...evaProps}
                style={[style.openSansRegular, style.label, style.colorLight]}>
                WhatsApp Number
              </Text>
            )}
            style={[style.input, style.boxWithShadow]}
            defaultValue={this.state.whatsApp}
            placeholder="+1234567890"
            keyboardType="number-pad"
            onChangeText={(e) => this.setState({whatsApp: e})}
          />
        </View>

        <View>
          <Text category="p1" style={[style.openSansRegular, style.colorLight]}>
            Country
          </Text>
          <Select
            selectedIndex={selectedIndex}
            style={[style.input, style.boxWithShadow]}
            value={this.state.country}
            defaultValue={this.state.country}
            onSelect={(index) => {
              console.log(index - 1);
              this.setState({
                state: '',
                country: this.state.countries.countries[index - 1].country,
                countryIndex: index - 1,
              });
            }}>
            {this.state.countries.countries.map((e, i) => (
              <SelectItem key={`${e.country}${i}`} title={e.country} />
            ))}
          </Select>
        </View>
        <View>
          <Text category="p1" style={[style.openSansRegular, style.colorLight]}>
            State
          </Text>
          <Select
            selectedIndex={selectedIndex}
            style={[style.input, style.boxWithShadow]}
            value={this.state.state}
            defaultValue={this.state.state}
            onSelect={(index) =>
              this.setState({
                state:
                  this.state.countries.countries[this.state.countryIndex]
                    .states[index - 1],
              })
            }>
            {(this.state.country
              ? this.state.countries.countries[this.state.countryIndex].states
              : []
            ).map((e, i) => (
              <SelectItem key={`${e}${i}`} title={e} />
            ))}
          </Select>
        </View>
        <View>
          <Input
            textStyle={{height: 30}}
            label={(evaProps) => (
              <Text
                category="p1"
                {...evaProps}
                style={[style.openSansRegular, style.label, style.colorLight]}>
                City
              </Text>
            )}
            style={[style.input, style.boxWithShadow]}
            defaultValue={this.state.city}
            placeholder="City/Town"
            onChangeText={(e) => this.setState({city: e})}
          />
        </View>
        <View>
          <Input
            textStyle={{height: 30}}
            label={(evaProps) => (
              <Text
                category="p1"
                {...evaProps}
                style={[style.openSansRegular, style.label, style.colorLight]}>
                Address
              </Text>
            )}
            style={[style.input, style.boxWithShadow]}
            placeholder="Landmark"
            defaultValue={this.state.address}
            onChangeText={(e) => this.setState({address: e})}
          />
        </View>
        <Button
          style={[
            style.sm_margin,
            style.primaryBackground,
            style.openSansRegular,
            style.noBorder,
          ]}>
          Submit
        </Button>
      </Card>
    );
  }
}
