import React, {Component} from 'react';
import {ProgressSteps, ProgressStep} from 'react-native-progress-steps';
import Header from '../components/header';
import {View, Image} from 'react-native';
import {Text, Button, Radio} from '@ui-kitten/components';
import Modal from '../components/modal';
import style from '../assets/style';
import ProfileInfo from '../components/ProfileInfo';
import * as Animatable from 'react-native-animatable';
import KYCInfo from '../components/KYCinfo';
import AccountDetails from '../components/AccountDetails';
import {color} from 'react-native-reanimated';

export default class Profile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modalVisible: true,
      radio2: false,
      radio1: false,
    };
  }
  onSubmit = () => {
    this.props.navigation.navigate('OrderSummary');
  };
  render() {
    const {radio1, radio2} = this.state;
    const buttonTextStyle = {
      color: '#fff',
      fontFamily: 'OpenSans-Regular',
      fontSize: 15,
    };
    return (
      <View style={[style.fullHeight, style.primaryBackground]}>
        <View style={style.dashboardContainer}>
          <Header
            navigation={this.props.navigation}
            title="Update Profile"
            stacknav
          />
        </View>
        <View style={[style.flex, style.whiteBackground]}>
          <ProgressSteps
            progressBarColor="#072956"
            activeStepIconBorderColor="#072956"
            labelFontFamily="OpenSans-Regular"
            activeLabelColor="#072956"
            completedStepIconColor="#072956"
            completedLabelColor="#072956"
            topOffset={20}
            completedProgressBarColor="#072956">
            <ProgressStep
              label="Basic Info"
              nextBtnTextStyle={buttonTextStyle}
              nextBtnStyle={style.stepsButtons}>
              <ProfileInfo />
            </ProgressStep>
            <ProgressStep
              label="KYC"
              nextBtnTextStyle={buttonTextStyle}
              previousBtnTextStyle={buttonTextStyle}
              previousBtnStyle={style.stepsButtons}
              nextBtnStyle={style.stepsButtons2}
              nextBtnTextStyle={{color: '#F0AB3C'}}>
              <KYCInfo />
            </ProgressStep>
            <ProgressStep
              label="Account Details"
              nextBtnTextStyle={buttonTextStyle}
              previousBtnTextStyle={buttonTextStyle}
              previousBtnStyle={style.stepsButtons}>
              <AccountDetails />
            </ProgressStep>
          </ProgressSteps>
        </View>
      </View>
    );
  }
}
