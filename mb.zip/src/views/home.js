import React, {Component} from 'react';
import {View} from 'react-native';
import {Text, Button, Card, Divider} from '@ui-kitten/components';
import * as Animatable from 'react-native-animatable';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {ScrollView} from 'react-native-gesture-handler';
import {Paystack} from 'react-native-paystack-webview';
import Header from '../components/header';
import style from '../assets/style';
import {_retrieveData} from '../services/asyncStorage';

const axios = require('axios');

export default class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      secureTextEntry: true,
      loading: false,
      modalVisible: false,
      user: {},
      referrals: [],
      paystackShow: false,
      paid:false
    };
  }

  componentDidMount() {
    _retrieveData('profile')
      .then((res) =>
        this.setState({user: JSON.parse(res)}, () => {
          this.getReferral(this.state.user.referralId);
        }),
      )
      .catch((err) => {});
  }

  getReferral(referralId) {
    axios
      .get(`http://vgloballink.com/api/v1/getReferrals/${referralId}`)
      .then((response) => {
        console.log(response);
        this.setState({referrals: response.data.data});
      })
      .catch((err) => {});
  }
  submit = () => {};

  render() {
    const {user, referrals} = this.state;

    return (
      <ScrollView style={style.whiteBackground}>
        <View style={[style.fullHeight, style.primaryBackground]}>
          <View style={style.dashboardContainer}>
            <Header navigation={this.props.navigation} title="Dashboard" />
            <View style={[style.walletContainer]}>
              <Text
                category="h6"
                style={[
                  style.regularFont,
                  style.colorLight,
                  style.textCenter,
                  style.sm_margin,
                ]}>
                Wallet Balance
              </Text>
              <Text
                category="h4"
                style={[style.regularFont, style.colorWhite, style.textCenter]}>
                <Text
                  category="p2"
                  style={[
                    style.regularFont,
                    style.colorWhite,
                    style.textCenter,
                  ]}>
                  ₦
                </Text>
                {this.state.paid ? "50,000" :"0"}
              </Text>
              <Button
                style={[
                  style.sm_margin,
                  style.center,
                  style.lightBackground,
                  style.noBorder,
                  style.fullWidth,
                ]}
                disabled={this.state.paid}
                onPress={() => {
                  this.setState({paystackShow: true});
                }}>
                {(evaProps) => (
                  <Text
                    {...evaProps}
                    style={[
                      style.regularFont,
                      style.colorWhite,
                      style.center,
                      style.displayFlex,
                    ]}>
                    {!this.state.paid ? 'Pay Now' : 'Active'}
                  </Text>
                )}
              </Button>
            </View>
          </View>
          <View style={[style.homeContainer, style.roundededges]}>
            <Text
              style={[style.boldFont, style.textCenter, style.sm_margin]}
              category="h6">
              You have {referrals.length} referrals
            </Text>
            {/* <Text style={[style.boldFont, style.sm_margin]} category="">Recent Transactions</Text> */}
            {this.state.paid &&
            <Card style={style.sm_margin}>
              <View
                style={[style.displayFlex, style.flexRow, style.spaceBetween]}>
                <View>
                  <Text category="h6" style={[style.boldFont]}>
                    50,000
                  </Text>
                  <Button
                    size="tiny"
                    style={[style.creditStatusButton, style.noBorder]}>
                    {(evaProps) => (
                      <Text
                        {...evaProps}
                        style={[
                          style.colorWhite,
                          style.statusText,
                          style.creditStatusText,
                        ]}>
                        Credit
                      </Text>
                    )}
                  </Button>
                </View>
               
                <View>
                  <Text
                    category="p2"
                    style={[style.openSansBold, style.textRight]}>
                    Fri,Dec 20th 2019
                  </Text>
                  <Text
                    category="h6"
                    style={[style.openSansBold, style.textRight]}>
                    50,000 (BALANCE)
                  </Text>
                </View>
              </View>
              <View style={[style.displayFlex, style.sm_margin]}>
                <Text
                  category="s2"
                  style={[style.openSansBold, style.textRight]}></Text>
              </View>
            </Card>}
          </View>
        </View>
        {this.state.paystackShow && (
          <View style={{flex: 1}}>
            <Paystack
              paystackKey="pk_test_88866eb856c55f2e82c99400b220abbad1c077f3"
              amount={'50000.00'}
              billingEmail="paystackwebview@something.com"
              activityIndicatorColor="green"
              onCancel={(e) => {
                // handle response here
                this.setState({paystackShow: false});
              }}
              onSuccess={(res) => {
                this.setState({paid:true})
                this.setState({paystackShow: false});
                // handle response here
              }}
              autoStart={true}
            />
          </View>
        )}
      </ScrollView>
    );
  }
}
