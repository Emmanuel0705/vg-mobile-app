import React, { Component } from 'react';
import { Linking, View } from 'react-native';
import {Text, Button, Card, Divider} from '@ui-kitten/components';
import * as Animatable from 'react-native-animatable';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { ScrollView } from 'react-native-gesture-handler';

import Header from '../components/header';
import style from '../assets/style';
import { _retrieveData } from "../services/asyncStorage";

const axios = require('axios');

export default class Referrals extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: {},
      referrals: []
    };
  }

  componentDidMount(){
    _retrieveData("profile")
    .then(res => this.setState({user: JSON.parse(res)}, () => {
      this.getReferral(this.state.user.referralId)
    }))
    .catch(err => {})
  }

  getReferral(referralId){
    axios.get(`http://vgloballink.com/api/v1/getReferrals/${referralId}`)
    .then(response => {
      this.setState({referrals: response.data.data})
    })
    .catch(err => {})

  }
  submit = () => {};

  render() {
    const { user, referrals } = this.state
    return (
      <ScrollView style={style.whiteBackground}>
        <View style={[style.fullHeight, style.primaryBackground]}>
          <View style={style.dashboardContainer}>
            <Header navigation={this.props.navigation} title="" />
            <View style={[style.walletContainer]}>
              <Text
                category="h6"
                style={[
                  style.regularFont,
                  style.colorLight,
                  style.textCenter,
                  style.sm_margin,
                ]}>
                You have {referrals.length} referrals
              </Text>
              <Text
                category="h4"
                style={[style.regularFont, style.colorWhite, style.textCenter]}>
                <Text
                  category="p2"
                  style={[
                    style.regularFont,
                    style.colorWhite,
                    style.textCenter,
                  ]}>
                </Text>
                Referral ID: {user.referralId}
              </Text>
              <Button 
                style={[
                  style.sm_margin,
                  style.center,
                  style.lightBackground,
                  style.noBorder,
                  style.fullWidth,
                ]}
                onPress={() => Linking.openURL('whatsapp://send?text=hello&phone=xxxxxxxxxxxxx')}>
                {(evaProps) => (
                  <Text
                    {...evaProps}
                    style={[
                      style.regularFont,
                      style.colorWhite,
                      style.center,
                      style.displayFlex,
                    ]}>
                    Share
                  </Text>
                )}
              </Button>
            </View>
          </View>
          <View style={[style.homeContainer, style.roundededges]}>
                   </View>
        </View>
      </ScrollView>
    );
  }
}
