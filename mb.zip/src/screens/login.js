import React, {Component} from 'react';
import {View, ScrollView, Dimensions} from 'react-native';
import {Layout, Text, Button} from '@ui-kitten/components';
import TextInput from 'react-native-textinput-with-icons';
import {SliderBox} from 'react-native-image-slider-box';
import {TouchableOpacity} from 'react-native-gesture-handler';
import Toast from 'react-native-toast-message';

import style from '../assets/style';
import {Loader} from '../components/loader';
import {_storeData} from '../services/asyncStorage';
// import {useDispatch} from "react-redux"
import { loginUser } from '../redux/actions/user.action';
const screenWidth = Dimensions.get('window').width - 50;
const axios = require('axios');

// const dispatch = useDispatch()

export default class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      secureTextEntry: true,
      showLoader: false,
      images: [
        require('../assets/images/Civic_Center.jpg'),
        require('../assets/images/bridge.jpg'),
        require('../assets/images/lagos_nigeria.jpg'),
      ],
    };
  }

  submit = () => {
    const {email, password} = this.state;
    if (!email) {
      Toast.show({
        type: 'error',
        position: 'top',
        text1: '',
        text2: 'Provide email address',
        visibilityTime: 4000,
      });
    } else if (!password) {
      Toast.show({
        type: 'error',
        position: 'top',
        text1: '',
        text2: 'Enter password',
        visibilityTime: 4000,
      });
    } else {
      this.setState({showLoader: true});
      let postBody = {
        email: this.state.email,
        password: this.state.password,
      };
      axios
        .post('http://vgloballink.com/api/v1/login', postBody)
        .then((response) => {
          this.setState({showLoader: false});
          if (response.status == 200) {
            this.props.navigation.navigate('Dashboard');
            _storeData('profile', response.data.data)
              .then((res) => {})
              .catch((err) => console.log(err));
          } else {
            Toast.show({
              type: 'error',
              position: 'top',
              text1: '',
              text2: response.message,
              visibilityTime: 4000,
            });
          }
        })
        .catch((err) => {
          this.setState({showLoader: false});
          Toast.show({
            type: 'error',
            position: 'top',
            text1: '',
            text2: err.response ? err.response.data.message : err,
            visibilityTime: 4000,
          });
        });
    }
  };
 async handleSubmit () {
    const {email, password} = this.state;
    if (!email) {
      Toast.show({
        type: 'error',
        position: 'top',
        text1: '',
        text2: 'Provide email address',
        visibilityTime: 4000,
      });
    } else if (!password) {
      Toast.show({
        type: 'error',
        position: 'top',
        text1: '',
        text2: 'Enter password',
        visibilityTime: 4000,
      });
    } else {
      this.setState({showLoader: true});
      let postBody = {
        email: this.state.email,
        password: this.state.password,
      };
      this.setState({showLoader: false});
      const res = await loginUser(postBody)()
      if(res.status){
        Toast.show({
          type: 'error',
          position: 'top',
          text1: '',
          text2: res.message,
          visibilityTime: 4000,
        });
        return
      }
      this.props.navigation.navigate('Dashboard');
      _storeData('profile', response.data.data)
        .then((res) => {})
        .catch((err) => console.log(err));
      this.setState({showLoader: false});
    }
  }

  render() {
    const {showLoader} = this.state;
    return (
      <Layout style={[style.fullHeight, style.lighterBackground]}>
        <Loader visible={showLoader} />
        <SliderBox
          images={this.state.images}
          sliderBoxHeight={400}
          autoplay
          circleLoop
        />
        <ScrollView>
          <View
            style={[
              style.authContainer,
              style.lighterBackground,
              style.fullHeight,
            ]}>
            <Text
              category="h6"
              style={[style.authText, style.colorPrimary, style.boldFont]}>
              Welcome Back
            </Text>
            <TextInput
              label="Email"
              leftIcon="email"
              leftIconSize={20}
              leftIconType="material"
              leftIconColor="#218BAC"
              rippleColor="#072956"
              fontFamily="Gotham-Book"
              underlineColor="#000"
              containerMaxWidth={screenWidth}
              underlineActiveColor="#000"
              labelActiveColor="#218BAC"
              containerWidth={screenWidth}
              value={this.state.email}
              refrance={(refrance) => {
                this.input = refrance;
              }}
              onChangeText={(email) => this.setState({email})}
            />
            <TextInput
              label="Password"
              leftIcon="lock"
              leftIconType="material"
              leftIconColor="#218BAC"
              leftIconSize={20}
              fontFamily="Gotham-Book"
              containerMaxWidth={screenWidth}
              containerWidth={screenWidth}
              labelActiveColor="#218BAC"
              underlineColor="#000"
              secureTextEntry
              value={this.state.password}
              refrance={(refrance) => {
                this.input = refrance;
              }}
              onChangeText={(password) => this.setState({password})}
            />
            <Text category="p2" style={[style.regularFont, style.textRight]}>
              Forgot your password?
            </Text>
            <Button
              style={[
                style.authroundedButton,
                style.primaryBackground,
                style.regularFont,
                style.noBorder,
                style.packageView,
              ]}
              size="medium"
              onPress={() => this.submit()}>
              {(evaProps) => (
                <Text
                  category="h6"
                  {...evaProps}
                  style={[style.boldFont, style.colorWhite]}>
                  Sign in
                </Text>
              )}
            </Button>
            {/* <SocialIcon
              title="Sign In With Google"
              button
              type="google"
              fontWeight="light"
              light
            /> */}
            <View
              style={[
                style.displayFlex,
                style.flexRow,
                style.createAccount,
                style.sm_margin,
              ]}>
              <Text ctaegory="p2" style={style.regularFont}>
                Don't have an account?
              </Text>
              <TouchableOpacity
                onPress={() => this.props.navigation.navigate('Register')}>
                <Text style={[style.regularFont, style.colorPrimary]}>
                  Register
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </Layout>
    );
  }
}
