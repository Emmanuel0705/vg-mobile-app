import React, {Component} from 'react';
import {View} from 'react-native';
import {Layout, Text, Input, Button} from '@ui-kitten/components';
import Toast from 'react-native-toast-message';
import { ScrollView } from 'react-native-gesture-handler';

import style from '../assets/style';
import { Loader } from "../components/loader"
import { _storeData } from "../services/asyncStorage";
const axios = require('axios');

export default class Register extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      secureTextEntry: true,
      firstName: "",
      lastName: "",
      sponsorId: "",
      phoneNumber: "",
      confirmPassword: "",
      showLoader: false,
    };
  }

  submit = () => {
    const { email, password, confirmPassword, firstName, lastName, phoneNumber } = this.state
    if(!email){
      Toast.show({
        type: 'error',
        position: 'top',
        text1: '',
        text2: 'Provide email address',
        visibilityTime: 4000,
      });
    }
    else if(!password || !confirmPassword){
      Toast.show({
        type: 'error',
        position: 'top',
        text1: '',
        text2: 'Enter password',
        visibilityTime: 4000,
      });
    }
    else if(password != confirmPassword){
      Toast.show({
        type: 'error',
        position: 'top',
        text1: '',
        text2: "Passwords don't match",
        visibilityTime: 4000,
      });
    }
    else if(!firstName){
      Toast.show({
        type: 'error',
        position: 'top',
        text1: '',
        text2: 'Enter first name',
        visibilityTime: 4000,
      });
    }
    else if(!lastName){
      Toast.show({
        type: 'error',
        position: 'top',
        text1: '',
        text2: 'Enter last name',
        visibilityTime: 4000,
      });
    }
    else if(!phoneNumber){
      Toast.show({
        type: 'error',
        position: 'top',
        text1: '',
        text2: 'Enter phone number',
        visibilityTime: 4000,
      });
    }
    else {
      this.setState({showLoader: true})
      axios.post("http://vgloballink.com/api/v1/register", this.state)
        .then(response => {
          this.setState({showLoader: false})
          if(response.status == 200){
            _storeData("profile",response.data)
            .then(res => {
              console.log(res);
              Toast.show({
                type: 'success',
                position: 'top',
                text1: '',
                text2: 'Registration Successful, referral ID sent to your mail',
                visibilityTime: 4000,
                onHide: () => {
                  this.props.navigation.navigate('Dashboard') 
                },
                onPress: () => {
                  this.props.navigation.navigate('Dashboard')
                }
              });
            })
            .catch(err => console.log(err))
          }
          else {
            Toast.show({
              type: 'error',
              position: 'top',
              text1: '',
              text2: response.message,
              visibilityTime: 4000,
            });
          }
        })
        .catch(err => {
          this.setState({showLoader: false})
          Toast.show({
            type: 'error',
            position: 'top',
            text1: '',
            text2: err.response ? err.response.data.message : err,
            visibilityTime: 4000,
          });
        })
    }
  };

  render() {
    const { showLoader } = this.state
    return (
      <Layout style={[style.authContainer, style.fullHeight]}>
        <Loader visible={showLoader} />
        <View>
          <Text
            category="h1"
            style={[style.authText, style.colorPrimary, style.boldFont]}>
            Create Account
          </Text>
        </View>
        <ScrollView>
        <View style={style.authView}>
          <Input
            placeholder="First name"
            style={[style.input, style.fullWidth]}
            value={this.state.firstName}
            onChangeText={(firstName) => this.setState({firstName})}
          />
          <Input
            placeholder="Last name"
            style={[style.input, style.fullWidth]}
            value={this.state.lastName}
            onChangeText={(lastName) => this.setState({lastName})}
          />
          <Input 
            placeholder="Email" 
            style={style.input}
            value={this.state.email}
            keyboardType="email-address"
            onChangeText={(email) => this.setState({email})}
          />
          <Input 
            placeholder="Phone number" 
            style={style.input}
            value={this.state.phoneNumber}
            onChangeText={(phoneNumber) => this.setState({phoneNumber})}
            keyboardType="phone-pad"
            />
          <Input
            placeholder="Password"
            value={this.state.password}
            onChangeText={(password) => this.setState({password})}
            secureTextEntry={this.state.secureTextEntry}
            onIconPress={this.onIconPress}
            style={style.input}
          />
           <Input
            placeholder="Confirm Password"
            value={this.state.confirmPassword}
            onChangeText={(confirmPassword) => this.setState({confirmPassword})}
            secureTextEntry={this.state.secureTextEntry}
            onIconPress={this.onIconPress}
            style={style.input}
          />
          <Input 
            placeholder="Sponsor ID" 
            value={this.state.sponsorId}
            style={style.input}
            onChangeText={(sponsorId) => this.setState({sponsorId})} 
          />
          <Button
            style={[
              style.authButton,
              style.primaryBackground,
              style.regularFont,
              style.noBorder,
            ]}
            onPress={() => this.submit()}>
            {(evaProps) => (
              <Text
                category="h5"
                {...evaProps}
                style={[style.boldFont, style.colorWhite]}>
                Sign up
              </Text>
            )}
          </Button>
        </View>
        </ScrollView>
      </Layout>
    );
  }
}
