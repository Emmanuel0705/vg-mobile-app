const variables = {
  secondaryColor: '#218BAC',
  primaryColor: '#F0AB3C',
  lightColor: '#3B5472',
  lighterColor: '#EFF7FC',
  white: '#fff',
  lightRed: '#FCA297',
  greyBackground: '#697B94',
  lightgrey: '#f4f5f7',
  darkgrey: '#919191',
  black: '#000',
};

export default variables;
