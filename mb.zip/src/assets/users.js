const APPUSERS = [
  {
    id: 1,
    firstName: 'Oluwatobi',
    lastName: 'Ajibola',
    email: 'emmanuelloluwatobi@gmail.com',
    phone: '09037271631',
    password: 'oluwatobi',
    sponsorId: 'ASBTS12',
    referralId: '3JSHI9D',
  },
  {
    id: 1,
    firstName: 'Samuel',
    lastName: 'Bolu',
    email: 'bolu.codehood@gmail.com',
    phone: '09037271631',
    password: 'samuel',
    sponsorId: 'STDR42D',
    referralId: 'THJ45NM',
  },

];

export default APPUSERS
