import APPUSERS from '../../assets/users';
import {STORE_USER_DATA, CLEAR_USER_DATA} from '../types/user.type';

export const storeUser = (payload) => async (dispatch) => {
  dispatch({
    type: STORE_USER_DATA,
    payload,
  });
};
export const loginUser = (payload) => async (dispatch) => {
  const {email, password} = payload;
  const user = APPUSERS.find((e) => e.email === email);
  if (!user)
    return {
      status: 'fail',
      message: 'user not found',
    };
    if(user.password !== password)return {
      status: 'fail',
      message: 'invalid password',
    };
  // dispatch({
  //   type: STORE_USER_DATA,
  //   payload:user,
  // });
  return user
};
export const clearUserData = () => async (dispatch) => {
  dispatch({
    type: CLEAR_USER_DATA,
  });
};
