import { STORE_USER_DATA, CLEAR_USER_DATA } from "../types/user.type";

const INITIAL_STATE = {
  data: {
    nok: [],
    emp: [],
    identity: [],
    gua: [],
    history: [],
    sec: [],
    banking: [],
    notifications: [],
    unreadNotifications: 0,
  },
};

const userReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case STORE_USER_DATA:
      return { ...state, data: action.payload };
    case CLEAR_USER_DATA:
      return { ...state, data: INITIAL_STATE.data };
    default:
      return state;
  }
};

export default userReducer;
