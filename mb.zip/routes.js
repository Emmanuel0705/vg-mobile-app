import React from 'react';
import StackNav from './src/navigation/stack';

const Routes = () => {
  return (
    <>
      <StackNav />
    </>
  );
};
export default Routes;
